#include "password.h"
#include "string.h"
#include "lcd.h"
#include "keypad.h"
#include <stdbool.h>

char password[] = "1234";
char entered[5];  // 4 digits + null
unsigned char index = 0;

void keypad_password()
{
    static unsigned char position = 0;
    char key = keypad_getkey();

    if (key)
    {
        if (key == '*') // Reset input
        {
            index = 0;
            position = 0;
            lcd_cmd(0xC0);
            lcd_str("                "); // Clear line
            lcd_cmd(0xC0);
            return;
        }

        if (key == '#') // Enter key
        {
            entered[index] = '\0';  // Null terminate
            lcd_cmd(0xC0);
            if (strcmp(entered, password) == 0)
            {
                lcd_str("Access Granted");
                // turn on lock LED or relay
            }
            else
            {
                lcd_str("Access Denied ");
                // blink red LED
            }

            __delay_ms(2000); // wait 2 sec
            index = 0;
            position = 0;
            lcd_cmd(0xC0);
            lcd_str("                "); // clear line
            lcd_cmd(0xC0);
            return;
        }

        if (index < 4)
        {
            entered[index++] = key;
            lcd_cmd(0xC0 + position);
            lcd_data('*');  // show * instead of real digit
            position++;
        }
    }
}

