#include <xc.h>
#include "lcd.h"
#include "keypad.h"
#define _XTAL_FREQ 20000000

void main(void)
{
    char key;
    unsigned char pos = 0;

    lcd_init();
    keypad_init();

    lcd_cmd(0x80);
    lcd_str("Press Key:");
       
    while(1)
    {
        keypad();
    };

    
}
