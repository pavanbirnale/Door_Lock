#include "keypad.h"
#include "lcd.h"
#include "password.h"
#include "uart.h"
#include <stdbool.h>

bool login(void);